package com.amazon.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.amazon.model.Response;
import com.amazon.searchService.Trie;

@RestController
@RequestMapping("/search")
public class SearchController {

	@Value("${keywords.list.of.strings}")
	private List<String> words;
	
	 Trie t = null; 
	 
	Map<String, Integer> scoremap = new HashMap<>();
	 
	 @InitBinder
	 public void load() {
		 t = new Trie();
		 words.forEach(w-> t.insert(w));  
	 }
	
	@RequestMapping(value="autocomplete/{name}", method=RequestMethod.GET)
	public ResponseEntity<Object> autocomplete(@PathVariable String name){
		
		if (scoremap.containsKey(name)) {
			int count = scoremap.get(name);
			scoremap.put(name, count + 1);
		} else {
			scoremap.put(name, 1);
		} 
        
		return new ResponseEntity<Object>(t.autocomplete(name),HttpStatus.OK);
	}
	
	@RequestMapping(value="estimate", method=RequestMethod.GET)
	public ResponseEntity<Response> estimate(@RequestParam("keyword") String keyword){
		
		Response response = new Response();
		if(null == scoremap || scoremap.isEmpty() || !scoremap.containsKey(keyword)) {
			response.setKeyword(keyword);
			response.setScore(0);
			return new ResponseEntity<Response>(response,HttpStatus.OK);
		}
		int score = scoremap.get(keyword);
		
		if(1<=score && score<=5) {
			response.setKeyword(keyword);
			response.setScore(10);
			return new ResponseEntity<Response>(response,HttpStatus.OK);
		}
		if(6<=score && score<=10) {
			response.setKeyword(keyword);
			response.setScore(20);
			return new ResponseEntity<Response>(response,HttpStatus.OK);
		}
		if(11<=score && score<=15) {
			response.setKeyword(keyword);
			response.setScore(30);
			return new ResponseEntity<Response>(response,HttpStatus.OK);
		}
		if(16<=score && score<=20) {
			response.setKeyword(keyword);
			response.setScore(40);
			return new ResponseEntity<Response>(response,HttpStatus.OK);
		}
		if(21<=score) {
			response.setKeyword(keyword);
			response.setScore(100);
			return new ResponseEntity<Response>(response,HttpStatus.OK);
		}
       
		return new ResponseEntity<Response>(response,HttpStatus.OK);
	}
	
}
