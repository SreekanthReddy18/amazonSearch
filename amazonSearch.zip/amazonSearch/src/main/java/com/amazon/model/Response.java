package com.amazon.model;

public class Response {

	private String keyword;
	
	private int score;

	public Response() {
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	@Override
	public String toString() {
		return "Response [keyword=" + keyword + ", score=" + score + "]";
	}
	
	
	
}
