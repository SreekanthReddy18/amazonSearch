package com.amazon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmazonSearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmazonSearchApplication.class, args);
	}

}
