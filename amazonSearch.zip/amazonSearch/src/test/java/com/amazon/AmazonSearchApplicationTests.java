package com.amazon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazonSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
